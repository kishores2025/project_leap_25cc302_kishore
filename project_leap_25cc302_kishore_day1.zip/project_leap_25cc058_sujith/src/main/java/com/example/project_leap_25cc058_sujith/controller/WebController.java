package com.example.project_leap_25cc058_sujith.controller;

import com.example.project_leap_25cc058_sujith.Model.Student;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WebController {
    @PostMapping("/calculate")
    int calculate(int a , int  b , String operation){
        switch (operation){
            case "+"->{
                return a + b;
            }
            case "-"->{
                return a - b;
            }

            case "*"->{
                return a * b;
            }

            case "/"->{
                return a / b;
            }
        }
        return 0;
    }

    @GetMapping("/student")
    public Student getStudentDetails(){
        Student student = new Student();
        student.setName("suji");
        student.setDeptartment("CCE");
        student.setRollNo("25CC058");
        return student;
    }

}
