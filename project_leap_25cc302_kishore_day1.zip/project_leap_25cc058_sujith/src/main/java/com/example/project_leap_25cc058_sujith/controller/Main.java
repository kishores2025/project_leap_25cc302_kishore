package com.example.project_leap_25cc058_sujith.controller;

public class Main {
     static void main(){
        WebController webcontroller = new WebController();
       IO.print(webcontroller.calculate(10 , 20 , "+"));
    }
}
