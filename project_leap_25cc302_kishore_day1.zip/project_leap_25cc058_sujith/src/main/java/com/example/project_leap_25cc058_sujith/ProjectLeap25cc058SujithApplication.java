package com.example.project_leap_25cc058_sujith;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectLeap25cc058SujithApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectLeap25cc058SujithApplication.class, args);
	}

}
