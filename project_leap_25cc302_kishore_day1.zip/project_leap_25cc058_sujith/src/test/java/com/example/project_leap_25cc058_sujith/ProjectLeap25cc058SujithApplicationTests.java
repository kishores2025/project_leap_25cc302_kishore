package com.example.project_leap_25cc058_sujith;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectLeap25cc058SujithApplicationTests {

	@Test
	void contextLoads() {
	}

}
